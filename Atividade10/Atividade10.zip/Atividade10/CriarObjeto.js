var Aluno1 = {

        ra: '0030482023021',
    
        nome: 'Lucas Maximiano dos Santos'
    
      }
    
      alert("1º Forma" + "\nRA: " + Aluno1.ra + "\nNome: " + Aluno1.nome);
    
      
    
      Aluno1.ra = '0030482023021';
    
      Aluno1.nome = 'Lucas Maximiano dos Santos';
    
      alert("2º Forma" + "\nRA: " + Aluno1.ra + "\nNome: " + Aluno1.nome);
    
      
    
      Aluno1['ra'] = '0030482023021';
    
      Aluno1['nome'] = 'Lucas Maximiano dos Santos';
    
      alert("3º Forma" + "\nRA: " + Aluno1.ra + "\nNome: " + Aluno1.nome);