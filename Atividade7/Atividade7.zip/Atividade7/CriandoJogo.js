    var jogador, maquina;
    var escJog, escMaq;
    
 
    jogador = prompt("Informe:\n(1) para pedra \n(2) Papel para  \n(3) Tesoura");
  

    maquina = Math.floor(Math.random() * 3);
    
    if(maquina == 0)
        maquina =3;

    if( jogador == 1)
        escJog = 'Pedra'
    else if ( jogador == 2)
        escJog = 'Papel'
    else
        escJog = 'Tesoura'

    if( maquina == 1)
        escMaq = 'Pedra'
    else if ( maquina == 2)
        escMaq = 'Papel'
    else
    escMaq = 'Tesoura'
    

    if(jogador == 1 && maquina == 3 || jogador == 2 && maquina == 1 || jogador == 3 && maquina == 2){
        alert('Jogador Wins!' +'\nJogador - ' + escJog + '\nMaquina - ' + escMaq);

        }
    
    
       else if(jogador == 1 && maquina == 2 || jogador == 2 && maquina == 3 || jogador == 3 && maquina == 1){
        alert('You Lose!!' +'\nJogador - ' + escJog + '\nMaquina -' + escMaq);
        }
    
       else{
        alert('Não creio empatou' +'\nJogador - ' + escJog + '\nMaquina - ' + escMaq);

    }


    var status = (fatec = "Sorocaba") && (semestre = 4) ? "Fatec Sorocaba - 4º Semestre" :"Outras Fatecs ou outro semestre";