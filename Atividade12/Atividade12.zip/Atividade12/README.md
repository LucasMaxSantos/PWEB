# Exercício 12 - Janela aberta, janela fechada e janela quebrada

<br>
Aula de PWEB | Professora: Denilce Veloso
<br>
<br>


* Encontre na rede 3 figuras: janela aberta, janela fechada e janela quebrada. Criar uma página que no 
carregamento mostra a janela fechada com um título “Abra a Janela”. 

* Se mover com o mouse sobre a imagem da janela fechada, mostra a janela aberta (abre a janela), se sair 
com o mouse da imagem mostra a janela fechada (fecha a janela). Se clicar sobre a imagem mostra a imagem da 
janela quebrada(quebra a janela).

<br>

![image](https://user-images.githubusercontent.com/78798697/174388223-6c3b832f-d49f-4cc6-9f2e-0ebc13a0f4b8.png)

_____________________________________________________________________________________________________________________________________________________


![image](https://user-images.githubusercontent.com/78798697/174388264-8e9e35ec-4a1d-4812-a532-77ecd9f1ddc1.png)

________________________________________________________________________________________________________________________________________________________________

![image](https://user-images.githubusercontent.com/78798697/174388331-6ce1858f-6777-455e-b069-de06805d7119.png)


> Resultado Janela aberta, janela fechada e janela quebrada. 

O projeto foi criado em:

- [x] Criação do HTML
- [x] Criação do CSS
- [x] Criação do JavaScript


## 🤝 Colaboradores

Pessoa que contribuiu para este projeto:

<table>
  <tr>
    <td align="center">
        <br>
          <b>Aline Herculano</b>
      </a>
    </td>
   </tr>
</table>
