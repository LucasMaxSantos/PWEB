    var i, idade = 0 , sexo, opiniao , otimoBom = 0, pessimo = 0, maisVelha = 0, maisNova = 100, h = 0, f = 0, idadeTotal = 0;

    
    for (i = 0; i < 3; i++){
            idade = parseInt(prompt('Qual é a sua idade?' ));
            sexo =  prompt('Informe o sexo: \nMasculino(M) \nou \nFeminino (F)');
            opniao = parseInt(prompt('Qual sua Opnião sobre o filme \nÓtimo (4), \nBom (3), \nRegular (2), \nPéssimo (1)'));
            idadeTotal = idadeTotal + idade;           
            if(idade > maisVelha)
                maisVelha = idade;
           
            if(idade < maisNova)
                maisNova = idade;
            
            if (opniao == 1 )
                pessimo++;
            
            if (opniao == 3 || opniao == 4)
                otimoBom++;
            
            if(sexo == 'M' || sexo == 'm')
                h++;
            else
                f++;
        }

    var media = (idadeTotal / i);
    otimoBom = (otimoBom/i) * 100;


    
    alert('A Média das idades é: ' + media.toFixed(2) + '\n A maior idade Foi: ' + maisVelha + '\n A menor idade é: ' + maisNova + '\nQuatidade de pessoas com opnião Péssimo: '  
        + pessimo + '\nA Porcentagem de Ótimo ou Bom é: ' + otimoBom.toFixed(2) +'%' + '\nTotal de Homens entrevistados: ' + h + '\nTotal de mulheres entrevistadas: ' + f);



        